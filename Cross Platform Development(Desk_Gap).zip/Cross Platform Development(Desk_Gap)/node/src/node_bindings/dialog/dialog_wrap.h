#ifndef dialog_dialog_wrap_h
#define dialog_dialog_wrap_h

#include <napi.h>

namespace DeskGap {
    Napi::Object DialogObject(const Napi::Env& env);
}

#endif

