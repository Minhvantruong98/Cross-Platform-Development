#ifndef native_exception_h
#define native_exception_h

#include <napi.h>

namespace DeskGap {
    const Napi::FunctionReference& NativeExceptionConstructor();
}

#endif /* native_exception_h */
