//
// Created by patr0nus on 2019/11/14.
//

#ifndef DESKGAP_INDEX_HPP
#define DESKGAP_INDEX_HPP

#include <napi.h>

namespace DeskGap {
    Napi::Object InitNodeNativeModule(Napi::Env env, Napi::Object exports);
}

#endif //DESKGAP_INDEX_HPP
