#ifndef platform_data_h
#define platform_data_h

namespace DeskGap {
    void* GetPlatformData();
}

#endif /* platform_data_h */
