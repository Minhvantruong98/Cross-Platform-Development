import deskgap = require('./types/node/index');
import './types/ui/preload';

export = deskgap;
