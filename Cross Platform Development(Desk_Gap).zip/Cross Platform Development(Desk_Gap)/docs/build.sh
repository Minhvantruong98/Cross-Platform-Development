cp README.md api/
mkdocs build
