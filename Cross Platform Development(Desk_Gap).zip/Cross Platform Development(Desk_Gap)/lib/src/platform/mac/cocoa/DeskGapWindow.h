#ifndef DeskGapWindow_h
#define DeskGapWindow_h

#import <Cocoa/Cocoa.h>

@interface DeskGapWindow: NSWindow
-(void)deskgap_startDragging;
@end

#endif
