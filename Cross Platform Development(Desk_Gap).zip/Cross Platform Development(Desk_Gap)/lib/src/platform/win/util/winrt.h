#ifndef win_util_winrt_h
#define win_util_winrt_h

#include <Windows.h>

namespace DeskGap {
    HMODULE GetWinRTDLLModule();
}

#endif
