﻿using static System.Console;
// Telephone number
long phoneNumber = 8989898989;
WriteLine($"Phone number : {phoneNumber}");
// Height
decimal height = 1.77M;
WriteLine($"Height : {height}");
// Age
int age = 24;
WriteLine($"Age : {age}");
// Salary
int salary = 25_000;
WriteLine($"Salary : {salary}");
// International standard book number
long isbn = 912345667433;
WriteLine($"Isbn : {isbn}");
// Book's Price
int bookPrice = 499;
WriteLine($"Book Price : {bookPrice}");
// Shipping weight
decimal weight = 8.4M;
WriteLine($"Weight : {weight}");
// Country's population
long population = 9_888_899;
WriteLine($"Country's population : {population}");
// Stars in universe
long stars = 789_888;
WriteLine($"Stars in universe : {stars}");
// Number of Employees
int employees = 9000;
WriteLine($"Number of Employees : {employees}");