## MCrossPDev
- C# 8.0 and .NET Core 3.0 - Modern Cross Platform Development Book .
#### **[ Developer : Blesslin Jerish R ]**
